Unofficial CADCraft modification for Ubuntu Xenial i386, built from
https://github.com/storytold/cadcraft at e86eacf094fefda1cdb6ba5137a336f29deb5d99.
Downstream code is licensed MIT OR Apache-2.0, like the original project.
Original ArtCraft trademark graphics are not used in this modified release.
The application icon is upstream contributor-original MIT OR Apache-2.0 artwork;
see upstream ASSETS.md or ATTRIBUTION.md. See build.json for optional font input details.
A private libxcb 1.17.0 is bundled under its original permissive notices.

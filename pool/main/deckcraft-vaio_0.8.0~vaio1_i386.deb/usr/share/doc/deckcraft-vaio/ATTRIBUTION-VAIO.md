Unofficial DeckCraft modification for Ubuntu Xenial i386, built from
https://github.com/storytold/deckcraft at cb78440a1618e6a2c1df55dd7bff74719685518c.
Downstream code is licensed MIT OR Apache-2.0, like the original project.
Original ArtCraft trademark graphics are not used in this modified release.
The application icon is upstream contributor-original MIT OR Apache-2.0 artwork;
see upstream ATTRIBUTION.md. See build.json for optional font input details.
A private libxcb 1.17.0 is bundled under its original permissive notices.

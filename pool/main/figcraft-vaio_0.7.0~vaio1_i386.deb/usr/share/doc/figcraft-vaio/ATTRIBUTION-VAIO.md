Unofficial FigCraft modification for Ubuntu Xenial i386, built from
https://github.com/storytold/figcraft at a0d1162976fac1e4a8b8fd49a3948e9d6bad6f40.
Downstream code is licensed MIT OR Apache-2.0, like the original project.
Original ArtCraft trademark graphics are not used in this modified release.
The application icon is upstream contributor-original MIT OR Apache-2.0 artwork;
see upstream ASSETS.md or ATTRIBUTION.md. See build.json for optional font input details.
A private libxcb 1.17.0 is bundled under its original permissive notices.

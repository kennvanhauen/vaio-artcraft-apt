Unofficial GridCraft modification for Ubuntu Xenial i386, built from
https://github.com/storytold/gridcraft at c30fa3f1cf324603f3bfc0171689b1d4083b40e5.
Downstream code is licensed MIT OR Apache-2.0, like the original project.
Original ArtCraft trademark graphics are not used in this modified release.
The application icon is upstream contributor-original MIT OR Apache-2.0 artwork;
see assets/app-icon/LICENSE.txt. No optional craft-fonts input is embedded.
A private libxcb 1.17.0 is bundled under its original permissive notices.

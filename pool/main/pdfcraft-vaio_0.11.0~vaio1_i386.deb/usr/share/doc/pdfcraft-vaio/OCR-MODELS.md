Unmodified Ocrs models by Robert Knight, trained on HierText.
Source: https://github.com/robertknight/ocrs-models
License: CC-BY-SA-4.0; attribution and pinned hashes in ATTRIBUTION.toml.
